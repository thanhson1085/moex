<?php
function sixscan_sanitize_input( $cur_url ){
}
?>